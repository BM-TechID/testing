import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import multer from "multer";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { v4 as uuidv4 } from "uuid";
import XLSX from "xlsx";
import fetch from "node-fetch";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 8787;

// ---------- CORS ----------
const allowed = (process.env.ALLOWED_ORIGINS || "*").split(",").map(s => s.trim());
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowed.includes("*") || allowed.includes(origin)) return cb(null, true);
    return cb(null, false);
  }
}));
app.options("*", cors());

// ---------- Parsers & Static ----------
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// ---------- Folders ----------
["uploads", "results"].forEach(d => {
  const p = path.join(__dirname, d);
  if (!fs.existsSync(p)) fs.mkdirSync(p);
});

// ---------- Multer ----------
const upload = multer({
  dest: path.join(__dirname, "uploads"),
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB
});

// ---------- In-memory Jobs ----------
const jobs = {}; // { id, status, total, processed, rows, resultPath, ... }

// ---------- Helpers ----------
function randomDelayMs() {
  const min = Number(process.env.DELAY_MIN_SEC || 1) * 1000;
  const max = Number(process.env.DELAY_MAX_SEC || 3) * 1000;
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function titleCase(s = "") {
  return s.toLowerCase().replace(/\s+/g, " ").trim().split(" ").map(w => (w ? w[0].toUpperCase() + w.slice(1) : "")).join(" ");
}
function formatNameCase(name) {
  const mode = (process.env.NAME_CASE || "TITLE").toUpperCase();
  if (!name) return name;
  if (mode === "UPPER") return String(name).toUpperCase();
  if (mode === "LOWER") return String(name).toLowerCase();
  return titleCase(String(name));
}
function demoName(bank, acc) {
  const names = ["Adi Pratama","Sari Wulandari","Budi Santoso","Dewi Lestari","Rizki Ramadhan","Maya Kartika","Eka Saputra","Lina Anjani"];
  const seed = (String(bank)+":"+String(acc)).split("").reduce((a,c)=>a+c.charCodeAt(0),0);
  return names[seed % names.length] + " (DEMO)";
}
function isNameMatching(inputName, resolvedName) {
  const a0 = (inputName ?? "").toString().trim();
  const b0 = (resolvedName ?? "").toString().trim();
  if (!a0 || !b0) return { match: false, reason: !b0 ? "no_name_from_provider" : "no_input_name" };
  const a = a0.toLowerCase().replace(/\s+/g, " ");
  const b = b0.toLowerCase().replace(/\s+/g, " ");
  if (a === b) return { match: true, reason: "exact" };
  const aW = a.split(" "), bW = b.split(" ");
  if (aW.length >= 2 && bW.length >= 2) {
    if (aW[0] + " " + aW.at(-1) === bW[0] + " " + bW.at(-1)) return { match: true, reason: "first_last" };
  }
  if (a.length > 4 && b.includes(a)) return { match: true, reason: "contained" };
  if (b.length > 4 && a.includes(b)) return { match: true, reason: "contained_rev" };
  return { match: false, reason: "different" };
}

// ---------- Provider Adapter (Atlantic Pedia) ----------
// Sesuai dokumentasi: x-www-form-urlencoded + api_key, bank_code, account_number  :contentReference[oaicite:1]{index=1}
async function checkAccountWithProvider(bank_code, account_number) {
  const base = process.env.AP_BASE_URL;
  const ep = process.env.AP_ENDPOINT;
  const apiKey = process.env.AP_API_KEY;

  if (!base || !ep || !apiKey) {
    return { ok: true, provider: "demo", account_name: formatNameCase(demoName(bank_code, account_number)), raw: null };
  }

  const url = `${base.replace(/\/$/, "")}${ep.startsWith("/") ? ep : `/${ep}`}`;

  const form = new URLSearchParams();
  form.set("api_key", apiKey);
  form.set("bank_code", String(bank_code).trim());
  form.set("account_number", String(account_number).trim());

  try {
    const resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: form
    });

    const rawText = await resp.text();
    let data; try { data = JSON.parse(rawText); } catch { data = rawText; }

    if (data?.status === true) {
      const api_status = data?.data?.status || "valid";
      const name = formatNameCase(data?.data?.nama_pemilik || data?.data?.name || null);
      return {
        ok: true,
        provider: "atlantic_h2h",
        api_status,
        account_name: name,
        raw: data
      };
    }

    // status false / invalid
    const api_status = data?.data?.status || "invalid";
    const msg = data?.message || "Account invalid";
    return { ok: false, provider: "atlantic_h2h", api_status, error: msg, raw: data };

  } catch (err) {
    return { ok: false, provider: "atlantic_h2h", error: String(err) };
  }
}

// ---------- Job Processor ----------
async function processJob(jobId) {
  const job = jobs[jobId];
  if (!job) return;
  job.status = "processing";
  job.processed = 0;
  job.total = job.rows.length;

  const results = [];

  for (let i = 0; i < job.rows.length; i++) {
    const row = job.rows[i];
    const bank = String(row.bank || "").trim().toLowerCase();
    const inputName = String(row.name || "").trim();
    const account = String(row.rek || row.account || "").replace(/\D/g, "");

    job.current = { index: i + 1, bank, inputName, account };

    try {
      const pr = await checkAccountWithProvider(bank, account);
      const account_valid = !!(pr.ok && pr.account_name);
      const nameInfo = isNameMatching(inputName, pr.account_name);
      const valid_name = !!nameInfo.match;

      // transparansi error & raw (dipotong)
      const error_message = pr.error || null;
      const raw_preview = pr.raw ? JSON.stringify(pr.raw).slice(0, 300) : null;

      results.push({
        bank,
        input_name: inputName,
        account,
        api_status: pr.api_status || (pr.ok ? "valid" : "invalid"),
        account_valid,
        resolved_name: pr.account_name || null,
        valid_name,
        match_reason: nameInfo.reason,
        provider_ok: !!pr.ok,
        provider: pr.provider || null,
        error_message,
        raw_preview
      });
    } catch (e) {
      results.push({
        bank, input_name: inputName, account,
        api_status: "error",
        account_valid: false,
        resolved_name: null,
        valid_name: false,
        match_reason: "error",
        provider_ok: false,
        provider: "atlantic_h2h",
        error_message: String(e),
        raw_preview: null
      });
    }

    job.processed = i + 1;
    await new Promise(r => setTimeout(r, randomDelayMs()));
  }

  // Tulis hasil ke XLSX
  const wb = XLSX.utils.book_new();
  const outSheet = XLSX.utils.json_to_sheet(results.map(r => ({
    bank: r.bank,
    input_name: r.input_name,
    account: r.account,
    api_status: r.api_status,
    account_valid: r.account_valid ? "YES" : "NO",
    resolved_name: r.resolved_name,
    valid_name: r.valid_name ? "YES" : "NO",
    match_reason: r.match_reason,
    provider_ok: r.provider_ok ? "YES" : "NO",
    provider: r.provider,
    error_message: r.error_message,
    raw_preview: r.raw_preview
  })));
  XLSX.utils.book_append_sheet(wb, outSheet, "results");

  const outPath = path.join(__dirname, "results", `${jobId}.xlsx`);
  XLSX.writeFile(wb, outPath);

  job.status = "done";
  job.resultPath = outPath;
  job.completedAt = new Date().toISOString();
}

// ---------- Routes ----------
// Health
app.get("/health", (_req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

// Template XLSX
app.get("/template", (_req, res) => {
  const wb = XLSX.utils.book_new();
  const sheet = XLSX.utils.json_to_sheet([{ bank: "bni", name: "Contoh Nama", rek: "1234567890" }]);
  XLSX.utils.book_append_sheet(wb, sheet, "template");
  const p = path.join(__dirname, "results", "template.xlsx");
  XLSX.writeFile(wb, p);
  res.download(p, "template_cek_rekening.xlsx");
});

// Upload XLSX (bulk)
app.post("/upload-xlsx", upload.single("file"), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ ok: false, error: "file not provided (field 'file')" });

    const filePath = req.file.path;
    const wb = XLSX.readFile(filePath);
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const json = XLSX.utils.sheet_to_json(sheet, { defval: "" });

    const rows = json.map(r => {
      const kv = Object.fromEntries(Object.entries(r).map(([k,v]) => [String(k).toLowerCase().trim(), v]));
      const bank =
        kv.bank ?? kv["bank code"] ?? kv.bank_code ?? kv.kode_bank ?? kv.kode ?? kv.kdbank ?? "";
      const name =
        kv.name ?? kv.nama ?? kv["account name"] ?? kv.account_name ?? kv.pemilik ?? kv["nama pemilik"] ?? "";
      const rek =
        kv.rek ?? kv["no rek"] ?? kv.norek ?? kv["no_rek"] ?? kv["no. rek"] ?? kv.account ?? kv.account_number ?? kv["account number"] ?? "";
      return { bank, name, rek };
    });

    fs.unlink(filePath, () => {});

    const jobId = uuidv4();
    jobs[jobId] = {
      id: jobId,
      status: "queued",
      total: rows.length,
      processed: 0,
      rows,
      createdAt: new Date().toISOString(),
      resultPath: null,
      error: null
    };

    processJob(jobId).catch(err => {
      jobs[jobId].status = "error";
      jobs[jobId].error = String(err);
    });

    res.json({ ok: true, jobId, total: rows.length });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// Status job
app.get("/job/:id", (req, res) => {
  const job = jobs[req.params.id];
  if (!job) return res.status(404).json({ ok: false, error: "job not found" });
  res.json({
    ok: true,
    id: job.id,
    status: job.status,
    total: job.total,
    processed: job.processed,
    createdAt: job.createdAt,
    completedAt: job.completedAt || null,
    error: job.error || null,
    download: job.status === "done" ? `/download/${job.id}` : null,
    current: job.current || null
  });
});

// Download hasil
app.get("/download/:id", (req, res) => {
  const job = jobs[req.params.id];
  if (!job) return res.status(404).send("job not found");
  if (job.status !== "done" || !job.resultPath) return res.status(400).send("result not ready");
  res.download(job.resultPath, `cek-rekening-${job.id}.xlsx`);
});

// Cek rekening satuan
app.post("/cek-rekening", async (req, res) => {
  try {
    const bank_code = String(req.body.bank_code || req.body.bank || "").trim().toLowerCase();
    const account_number = String(req.body.account_number || req.body.norek || req.body.account || "").replace(/\D/g, "");
    const input_name = String(req.body.input_name || req.body.name || "").trim();

    if (!bank_code || !account_number) {
      return res.status(400).json({ ok: false, error: "bank_code & account_number wajib diisi" });
    }

    const pr = await checkAccountWithProvider(bank_code, account_number);
    const account_valid = !!(pr.ok && pr.account_name);
    const nameCheck = isNameMatching(input_name, pr.account_name);
    const valid_name = input_name ? !!nameCheck.match : null;

    res.json({
      ok: true,
      bank_code,
      account_number,
      account_valid,
      api_status: pr.api_status || (pr.ok ? "valid" : "invalid"),
      provider_ok: !!pr.ok,
      provider: pr.provider,
      resolved_name: pr.account_name || null,
      input_name: input_name || null,
      valid_name,
      match_reason: input_name ? nameCheck.reason : null,
      error_message: pr.error || null,
      raw: pr.raw ?? null
    });
  } catch (e) {
    res.status(502).json({ ok: false, error: String(e) });
  }
});

// UI
app.get("/", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Gateway Bulk Check running on http://localhost:${PORT}`);
});
